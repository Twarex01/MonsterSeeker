package com.example.monsterseeker.models

data class ListMonster(
    val name: String,
    val favourite: Boolean
)