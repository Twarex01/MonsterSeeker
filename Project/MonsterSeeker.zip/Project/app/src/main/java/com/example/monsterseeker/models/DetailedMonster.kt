package com.example.monsterseeker.models

data class DetailedMonster(
    val name: String,
    val description: String
)