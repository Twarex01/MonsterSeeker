package com.example.monsterseeker.dtos

data class NewMonster(
    val name: String,
    val description: String
)